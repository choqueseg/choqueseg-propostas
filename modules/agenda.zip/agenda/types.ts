export type PerfilUsuario = "administrador" | "funcionario";

export type Cliente = {
  id: string;
  nome: string;
  telefone: string;
  cidade: string;
  endereco: string;
  tipoServico: string;
};

export type Funcionario = {
  id: string;
  nome: string;
  usuario: string;
  nivelAcesso: string;
  status: "Ativo" | "Inativo";
};

export type ItemChecklist = {
  id: string;
  titulo: string;
  concluido: boolean;
};

export type MaterialUtilizado = {
  id: string;
  descricao: string;
  quantidade: string;
};

export type Servico = {
  id: string;
  clienteId: string;
  clienteNome: string;
  clienteTelefone?: string;
  tipoServico: string;
  data: string;
  horario: string;
  endereco: string;
  cidade: string;
  equipe: string;
  descricao: string;
  status: "Agendado" | "Em execução" | "Concluído";

  checklist?: ItemChecklist[];
  materiais?: MaterialUtilizado[];
  observacoesTecnico?: string;
  iniciadoEm?: string;
  concluidoEm?: string;
  concluidoPor?: string;
};